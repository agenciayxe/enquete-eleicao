
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta name="application-name" content="<?php echo e(config('app.name', 'Laravel')); ?>">

    <meta name="apple-mobile-web-app-title" content="<?php echo e(config('app.name', 'Laravel')); ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">

    <link rel="shortcut icon" href="<?php echo e(url('favicon.ico')); ?>">

    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">

    <base href="<?php echo e(url('/')); ?>">
</head>
<body>
    <div id="app">
        <div id="vue-loading"><?php echo e(__('strings.loading')); ?>...</div>
    </div>

    <script>
      var baseUrl = '<?php echo e(url('/api')); ?>';
    </script>
    <script src="<?php echo e(mix('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\wamp\www\agenciakls\eleicao2022\resources\views/app.blade.php ENDPATH**/ ?>