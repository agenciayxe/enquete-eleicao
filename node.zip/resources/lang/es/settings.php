<?php

return [

    'new_password' => 'Nueva contraseña',
    'password_confirmation' => 'confirmación de contraseña',

];
