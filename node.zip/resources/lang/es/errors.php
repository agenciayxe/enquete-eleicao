<?php

return [

    'fatal_error' => 'Se produjo un error fatal, póngase en contacto con nosotros.',
    'generic_error' => 'Ha ocurrido un error. Por favor intente de nuevo.',
    'unauthorized' => 'No autorizado.',

];
