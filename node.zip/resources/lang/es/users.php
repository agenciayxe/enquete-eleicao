<?php

return [

    'add_user' => 'Agregar usuario',
    'edit_user' => 'Editar usuario',
    'no_users' => 'No hay usuarios registrados',
    'user_type' => 'Tipo de usuario',

    'search' => 'Búsqueda de usuarios',

];
