<?php

return [

    'add' => 'Añadir',
    'approve' => 'Aprobar',
    'cancel' => 'Cancelar',
    'change_file' => 'Cambiar archivo',
    'choose_file' => 'Elija el archivo',
    'delete' => 'Borrar',
    'edit' => 'Editar',
    'ok' => 'OK',
    'open' => 'Abierto',
    'publish' => 'Publicar',
    'reject' => 'Rechazar',
    'save' => 'Salvar',
    'sending' => 'Enviando',
    'update' => 'Actualizar',

];
