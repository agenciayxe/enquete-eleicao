<?php

return [

    'logout' => 'Log out',
    'manage' => 'MANAGE',
    'welcome' => 'Welcome, :name',

];
