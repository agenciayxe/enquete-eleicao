<?php

return [

    'add_user' => 'Add user',
    'edit_user' => 'Edit user',
    'no_users' => 'There are no registered users.',
    'user_type' => 'User type',

    'search' => 'Users Search',

];
