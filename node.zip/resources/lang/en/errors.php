<?php

return [

    'fatal_error' => 'A fatal error occurred, please contact us.',
    'generic_error' => 'An error occurred, please try again.',
    'unauthorized' => 'Unauthorized.',
    'forbidden' => 'Forbidden.',

];
