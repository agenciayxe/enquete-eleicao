<?php

return [

    'logout' => 'Sair',
    'manage' => 'GERENCIAR',
    'welcome' => 'Bem-vindo, :name',

];
