<?php

return [
    'add_survey' =>  'Adicionar Pesquisa',
    'edit_survey' =>  'Editar Pesquisa',

    'executions.1' => 'Tudo',
    'executions.2' => 'Grupo',
    'executions.3' => 'Um por vez',

    'unique.0' => 'Não',
    'unique.1' => 'Sim',

    'afterword' => 'Texto Final',
    'cover' => 'Capa',
    'description' => 'Descrição',
    'due_at' => 'Vencimento',
    'execution' => 'Execução',
    'final_sound' => 'Som Final',
    'id' => '#',
    'introduction' => 'Introdução',
    'name' => 'Nome',
    'questions' => 'Questões',
    'unique' => 'Voto Único',
];
