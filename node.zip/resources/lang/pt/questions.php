<?php

return [

    'add_question' => 'Adicionar Questão',
    'edit_question' => 'Editar Questão',

    'body' => 'Conteúdo',
    'group' => 'Grupo',
    'id' => '#',
    'order' => 'Ordem',
    'type' => 'Tipo',

];
