<?php

return [

    'add' => 'Adicionar',
    'approve' => 'Aprovar',
    'back' => 'Voltar',
    'cancel' => 'Cancelar',
    'change_file' => 'Atualizar arquivo',
    'choose_file' => 'Escolher arquivo',
    'delete' => 'Apagar',
    'edit' => 'Editar',
    'ok' => 'OK',
    'open' => 'Abrir',
    'publish' => 'Publicar',
    'reject' => 'Rejeitar',
    'update' => 'Atualizar',
    'save' => 'Salvar',
    'sending' => 'Enviando',

];
