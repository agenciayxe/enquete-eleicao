<?php

return [

    'new_password' => 'Nova senha',
    'password_confirmation' => 'Confirmar senha',

];
