<?php

return [

    'add_answer' => 'Adicionar Resposta',
    'edit_answer' => 'Editar Resposta',

    'body' => 'Conteúdo',
    'id' => '#',
    'image' => 'Imagem',
    'justify' => 'Justifica',
    'order' => 'Ordem',

];
