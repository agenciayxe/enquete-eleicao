<?php

return [

    'deleted_successfully' => 'Apagado com sucesso.',
    'password_changed_successfully' => 'Senha alterada com sucesso.',
    'passwords_not_match' => 'Senhas não coincidem.',
    'settings' => 'Configurações',

    'delete_user_confirmation' => 'Tem certeza que deseja apagar esse usuário?',
    'language' => 'Português',
    
];
