<?php

return [

    'fatal_error' => 'Ocorreu um erro fatal, por favor, entre em contato.',
    'generic_error' => 'Houve um erro, tente novamente.',
    'unauthorized' => 'Não autorizado.',
    'forbidden' => 'Proibido.',

];
