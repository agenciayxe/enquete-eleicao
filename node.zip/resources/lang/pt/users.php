<?php

return [

    'add_user' => 'Adicionar usuário',
    'edit_user' => 'Editar usuário',
    'no_users' => 'Não há usuários cadastrados.',
    'user_type' => 'Tipo de usuário',

    'search' => 'Pesquisa de usuários',

];
