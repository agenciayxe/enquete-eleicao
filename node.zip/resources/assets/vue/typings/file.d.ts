declare interface File {
    
}