declare interface Error {
    [key: string]: [string]
}