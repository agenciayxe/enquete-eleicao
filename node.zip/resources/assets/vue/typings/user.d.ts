declare interface User {
  id: number;
  email: string;
  name: string;
  type: string;
  type_id: number;
  password: string;
  password_confirmation: string;
}
