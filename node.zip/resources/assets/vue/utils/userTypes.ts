enum userTypes {
  ADMIN = 1,
  NORMAL = 2,
}

export default userTypes;
