export default {
  publicMessages: [],
  privateMessages: [],
  unread: 0,
};
