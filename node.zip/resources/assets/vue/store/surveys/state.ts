export default {
  errors: {},
  isLoading: false,
  isSubmitting: false,
  pagination: {
    currentPage: 1,
    perPage: 5,
    totalUsers: 0,
    totalPages: 0
  },
  survey: null,
  surveys: [],
};
