export default {
  mode: 'history',
  routes: [{
    path: '/',
    name: 'Home',
  }, {
    path: '/users',
    name: 'Users',
  }],
};
