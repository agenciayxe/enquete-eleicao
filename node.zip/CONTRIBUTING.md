# Contributing

The development of this software is based on the [Alefe Souza Project Guidelines](https://github.com/alefesouza/project-guidelines).
